#!/bin/bash
version='808104Beta'
browser='Chrome'
echo $version$browser
cat ./manifest$browser/manifest.json > src/manifest.json
cd ./src
zip bboalert$browser$version.zip *.* -x *.zip -x test*.* -x *.sh -x workspace.*
mv *.zip ..
cd ..


