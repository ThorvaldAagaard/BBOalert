t = document.querySelectorAll("table.whole-row");
var txt = [];
t.forEach(function (e) {
    var n = parseInt(e.getAttribute("data-level"));
    if (n == 1) indent = "\n";
    if (n == 2) indent = "- ";
    if (n > 2) {
        indent = "";
        for (var i = 2; i < n; i++) { indent = indent + "    " };
        indent = indent + "- ";
    }
    txt.push(indent + e.querySelector("td.column").textContent);
});
data = "";
data = txt.join('\n');
console.log(data);
$("bridge-screen .biddingBoxClass", window.parent.document).hide(0, function () { $("bridge-screen .biddingBoxClass", window.parent.document).show();})

var bb = getBiddingBox()
bb.style.display = "none";
setTimeout(function () {
    bb.style.display = "inline-block";
}, 200);
