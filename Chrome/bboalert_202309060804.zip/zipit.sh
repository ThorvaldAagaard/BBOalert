#!/bin/bash
zip ./ZIP/bboalert_$(date "+%Y%m%d%H%M").zip *.* ./*/*.* -x *.zip




